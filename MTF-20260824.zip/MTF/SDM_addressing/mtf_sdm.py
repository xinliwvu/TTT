"""
mtf_sdm.py
==========
A cerebellar sparse-distributed-memory ADDRESSING layer for the E-D-T cycle.

WHY
---
The programme's diagnosis is precise: retention is solved (frozen experts,
BWT ~ -0.14 even when accuracy is poor), boundary detection is solved (H_M,
10/10, 20/20 cyclic), but ADDRESSING is not.  The router -- nearest centroid
over prototype MEANS -- fails exactly where a context is a union of clusters:
the mean of well-separated clusters lands near the global mean and inside none
of them (measured: inter-task-mean distances ~ 0.3x inter-class-mean distances;
rho_cent = 0.263 on CIFAR-CIL against 0.921 on Permuted-MNIST).  One key per
cell cannot represent a union of clusters.

A Kanerva/Marr-Albus sparse code CAN.  The mossy->granule expansion is a fixed
random projection D -> D' followed by top-k competition; a context is stored
not as one mean but as a COUNTER VECTOR over the D' locations its samples
activate -- the natural representation of a union.  A test sample re-activates
the locations of its own cluster, which were written by its own context,
whatever the other clusters of that context look like.  Reads are
overlap-weighted votes; the recognition gate follows from overlap statistics
(Kanerva's critical distance) instead of the miscalibrated L2 radius tau_mu.

Mapping to the biology (motivation, never evidence):
    mossy -> granule expansion  =  fixed random projection + top-k sparsity
    Purkinje readouts           =  the existing frozen experts
    climbing-fiber error        =  the existing H_M alarm (untouched here)

WHAT THIS MODULE TOUCHES, AND WHAT IT DOES NOT
----------------------------------------------
Replaced when enabled:
    Recognize      batch-mean L2-radius test  ->  per-sample overlap majority
    predict        nearest-centroid routing   ->  SDM overlap-weighted vote
Untouched, always:
    Evaluate, Detect (H_M / H_T), the gate, allocation, freezing, training,
    centroid bookkeeping (kept for diagnostics and for the disabled path).

`SDMConfig(enabled=False)` reproduces the base machine BIT-FOR-BIT: the
overrides delegate to `UrysohnMachine` before any SDM state is created and no
random number is drawn -- the ablatable-axis discipline of `mtf_ttt_slow.py`.
Verified in the self-test.

THE ADDRESS CODE
----------------
    a(z) = top-k( W z ),  W in R^{D' x D} fixed Gaussian, k = density * D'.

Writes:  every observe() batch adds each sample's activated location set to the
counter column of the expert active AFTER the Transform decision -- including
recognized (frozen) revisits.  That reinforcement is the trap: a returning
context re-activates and re-strengthens its own locations while its expert's
weights stay frozen, so (F4) is untouched (the expansion is fixed, counters
never enter the prediction function of any expert).

Reads:  score_e(z) = sum over activated locations l of the location posterior
p(e | l) = C[l,e] / sum_e' C[l,e'].  Hard routing takes argmax; `route='soft'`
blends expert logits with softmax(score / T) -- the graceful-degradation read.

Recognition gate (replaces tau_mu when enabled):  expert e's stored profile is
its k most-written locations, hat-a_e.  A sample HITS e when its overlap
|a(z) & hat-a_e| exceeds a threshold, and the batch recognizes e when a
MAJORITY of samples hit e.  Counting per-sample events is what sidesteps the
batch-mean concentration mismatch (the sqrt(1+1/n) issue): nothing here
concentrates as the batch grows.

THE NULL MUST BE MEASURED, NOT ASSUMED (a falsification, kept with equal
billing).  v0.1 derived the hit threshold from the independence null
(hypergeometric: mu0 = k^2/D', Chernoff tail).  Real data falsified it:
on Split-MNIST pixels the CROSS-context overlap is ~6x the combinatorial null
(63.5 vs 11.1 at D'=12288, k=368) because different contexts share input
structure; the gate then recognized everything and the library collapsed to 2
experts for 5 contexts (measured; cyclic run, v0.1).  This is the tau_mu
lesson again, one representation up: calibrate the test on the statistic it
actually gates.  v0.2 measured BOTH sides online -- same_e (overlap of batches vs e's profile
while e is active; own-context by construction) and cross_e (while inactive;
cross-context by construction) -- and gated at their midpoint.  The real
cyclic stream falsified THAT too: the cross-context overlap distribution is
heterogeneous across context pairs (digit-pair similarity varies), so a
midpoint calibrated against the contexts seen so far false-recognizes a novel
context that happens to resemble a stored one more than the average.  And a
wrong recognition is an ABSORBING state: the wrong expert is frozen (F4), its
loss on the new context is high but FLAT, and the abs_guard keeps H_M silent
-- measured: oracle-routed accuracy collapsed to 0.20-0.59 on 4/5 seeds while
the alarm never re-fired.

v0.3/v0.3.1 (current) therefore:
  * `recognize='overlap'` gates on the SAME-side band alone: a sample hits e
    iff  overlap >= same_mean_e - z_alpha * same_sd_e,
    z_alpha = Phi^{-1}(1 - alpha_false_hit) -- a scale-free z-score, not a
    radius; consistency-with-own-context is the test, novelty is the default.
    v0.3.1 computes same_e over a RECENT window (256) because all-history
    stats are inflated by the young-profile phase.  MEASURED RESULT, reported
    plainly: on the real cyclic stream both variants still collapse
    identically (24.4 +- 5.5, 2 experts for 5 contexts) -- the fatal false
    recognitions occur at the first boundaries, where window == history and
    every profile is immature.  Per-sample-address recognition without task
    labels remains OPEN after three falsified gate designs; use
    `recognize='centroid'` for deployment and see the findings report.
  * `recognize='centroid'` keeps the base machine's recognition rule
    (tau_mu on batch means) UNTOUCHED and uses SDM only for writes + routing
    -- the ablation that decomposes router gains from gate gains.
  * until same_e holds `bg_min` observations the gate abstains for e
    (allocation is the safe failure mode -- over-provisioning is recoverable,
    a wrong recognition is absorbing); and the majority is taken over TOTAL
    hits with the winner the vote-max among hitting samples -- per-candidate
    majorities let duplicate experts split the vote and trigger a third
    duplicate (measured: 15-expert runaway on the 4-context self-test).

Run `python mtf_sdm.py` for the self-test.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Optional
import math

import numpy as np

try:
    import torch
    _HAS_TORCH = True
except Exception:                                        # pragma: no cover
    torch = None
    _HAS_TORCH = False

from mtf_ttt import EDTConfig, UrysohnMachine, Decision

__all__ = ["SDMConfig", "SDMAddressSpace", "AddressedUrysohnMachine"]
__version__ = "0.3.1"


# ---------------------------------------------------------------- config
@dataclass
class SDMConfig:
    """Every constant of the addressing layer, in one place.

    Defaults follow the Marr-Albus regime: large expansion, 2-5% coding level.
    `enabled=False` MUST reproduce the base machine bit-for-bit (self-tested).
    """
    enabled: bool = True
    dim: int = 12288                 # D', the granule-layer width
    density: float = 0.03            # k / D'  (top-k coding level)
    seed: int = 0                    # projection seed -- NEVER the global RNG
    route: str = "hard"              # 'hard' argmax vote | 'soft' blended read
    soft_temp: float = 0.1           # temperature for the soft read
    recognize: str = "overlap"       # 'overlap' z-band gate | 'centroid' (base
                                     #   rule untouched; SDM = writes + routing)
    alpha_false_hit: float = 1e-2    # per-batch false-recognition budget
    vote_majority: float = 0.5       # batch fraction of hits to recognize
    smooth: float = 1e-3             # Laplace smoothing of location posteriors
    write_frozen: bool = True        # reinforce on recognized (frozen) revisits
    normalize_input: bool = False    # L2-normalize features before projecting
    bg_min: int = 64                 # background samples before e is gateable

    def __post_init__(self):
        if self.route not in ("hard", "soft"):
            raise ValueError(f"route must be 'hard' or 'soft', got {self.route!r}")
        if self.recognize not in ("overlap", "centroid"):
            raise ValueError(f"recognize must be 'overlap' or 'centroid', "
                             f"got {self.recognize!r}")
        if not (0.0 < self.density < 1.0):
            raise ValueError("density must be in (0,1)")

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def k(self) -> int:
        return max(int(round(self.density * self.dim)), 1)


# ---------------------------------------------------------------- address space
class SDMAddressSpace:
    """The granule layer: fixed random projection, top-k competition, and one
    Kanerva counter column per expert.

    Pure mechanism -- no knowledge of the E-D-T cycle.  All state that learning
    touches lives in `counts`; the projection is fixed at construction from a
    dedicated seed and is never trained (what preserves (F4) compatibility).
    """

    def __init__(self, in_dim: int, cfg: SDMConfig, device=None, dtype=None):
        self.cfg = cfg
        self.in_dim = int(in_dim)
        self.k = cfg.k
        rs = np.random.RandomState(cfg.seed)             # dedicated, never global
        Wnp = rs.normal(0.0, 1.0 / math.sqrt(self.in_dim),
                        size=(cfg.dim, self.in_dim)).astype(np.float32)
        self.W = torch.as_tensor(Wnp, device=device, dtype=dtype or torch.float32)
        self.counts = torch.zeros(cfg.dim, 0, dtype=torch.float32,
                                  device=device)          # (D', K) grows with K
        self.writes_per_expert: list = []                 # samples written per col

    # -- encoding --------------------------------------------------------
    @torch.no_grad()
    def encode(self, z: "torch.Tensor") -> "torch.Tensor":
        """(B, D) -> (B, k) int64 indices of activated locations."""
        z = z.to(self.W.dtype)
        if self.cfg.normalize_input:
            z = torch.nn.functional.normalize(z, dim=1)
        u = z @ self.W.T                                  # (B, D')
        return u.topk(self.k, dim=1).indices

    # -- write -----------------------------------------------------------
    def ensure_expert(self, eid: int) -> None:
        while self.counts.shape[1] <= eid:
            self.counts = torch.cat(
                [self.counts, torch.zeros(self.cfg.dim, 1,
                                          dtype=self.counts.dtype,
                                          device=self.counts.device)], dim=1)
            self.writes_per_expert.append(0)

    @torch.no_grad()
    def write(self, idx: "torch.Tensor", eid: int) -> None:
        """Reinforce the activated locations of every sample, tagged `eid`."""
        self.ensure_expert(eid)
        flat = idx.reshape(-1)
        self.counts[:, eid].scatter_add_(
            0, flat, torch.ones_like(flat, dtype=self.counts.dtype))
        self.writes_per_expert[eid] += int(idx.shape[0])

    # -- read ------------------------------------------------------------
    @torch.no_grad()
    def scores(self, idx: "torch.Tensor") -> "torch.Tensor":
        """(B, k) indices -> (B, K) overlap-weighted vote.

        score_e = sum over activated l of p(e | l), the location posterior with
        Laplace smoothing.  Per-sample by construction; no batch statistic.
        """
        K = self.counts.shape[1]
        if K == 0:
            return torch.zeros(idx.shape[0], 0, device=idx.device)
        post = self.counts / (self.counts.sum(dim=1, keepdim=True)
                              + self.cfg.smooth)          # (D', K)
        return post[idx.reshape(-1)].reshape(idx.shape[0], self.k, K).sum(dim=1)

    # -- recognition statistics -----------------------------------------
    @torch.no_grad()
    def profiles(self) -> Optional["torch.Tensor"]:
        """(K, k) each expert's k most-written locations, or None if no writes."""
        K = self.counts.shape[1]
        if K == 0 or all(w == 0 for w in self.writes_per_expert):
            return None
        return self.counts.topk(self.k, dim=0).indices.T   # (K, k)

    def null_overlap(self):
        """(mu0, sigma0) of |a(z) & hat-a_e| for an UNRELATED input:
        hypergeometric(D', k, k)."""
        D, k = float(self.cfg.dim), float(self.k)
        mu0 = k * k / D
        var = k * (k / D) * (1 - k / D) * (D - k) / (D - 1)
        return mu0, math.sqrt(max(var, 1e-12))

    def hit_threshold(self, n_experts: int) -> float:
        """theta = mu0 + sqrt(2 mu0 ln(K/alpha)): Chernoff tail on the null,
        Bonferroni across the K stored profiles.  Derived from (D', k, K) --
        the parameter-free replacement of tau_mu."""
        mu0, _ = self.null_overlap()
        K = max(n_experts, 1)
        return mu0 + math.sqrt(2.0 * mu0 *
                               math.log(K / self.cfg.alpha_false_hit))

    @torch.no_grad()
    def overlaps(self, idx: "torch.Tensor",
                 prof: "torch.Tensor") -> "torch.Tensor":
        """(B, k) indices x (K, k) profiles -> (B, K) integer overlaps."""
        D = self.cfg.dim
        B, K = idx.shape[0], prof.shape[0]
        pmask = torch.zeros(K, D, dtype=torch.bool, device=idx.device)
        pmask.scatter_(1, prof, True)
        out = torch.zeros(B, K, dtype=torch.float32, device=idx.device)
        for e in range(K):                                # K is small
            out[:, e] = pmask[e][idx].sum(dim=1).float()
        return out

    def memory_bytes(self) -> int:
        return (self.W.numel() + self.counts.numel()) * 4


# ---------------------------------------------------------------- machine
class AddressedUrysohnMachine(UrysohnMachine):
    """UrysohnMachine + the SDM addressing layer.

    Drop-in: same `observe` / `predict` API.  `sdm.enabled = False` recovers
    the original machine exactly, making addressing an ablatable axis rather
    than a fork.  The alarm, the gate, allocation and freezing are untouched
    on every path.
    """

    def __init__(self, *args, sdm: Optional[SDMConfig] = None, **kw):
        super().__init__(*args, **kw)
        self.sdm = sdm or SDMConfig()
        self.space: Optional[SDMAddressSpace] = None      # lazy: needs D
        self.recognition_log: list = []   # (step, eid|None, majority_frac, theta)
        self._bg: dict = {}    # eid -> [n, mean, M2]: overlap vs eid's profile
                               # of samples seen while eid NOT active (cross-
                               # context by construction)
        from collections import deque
        self._same: dict = {}  # eid -> deque of recent overlaps vs eid's own
                               # profile while eid IS active (own-context).
                               # WINDOWED (last 256), not all-history: early
                               # overlaps are measured against a still-young
                               # profile and inflate the variance -- the
                               # all-history variant false-recognized (v0.3,
                               # measured: 2 experts for 5 contexts).
        self._same_maker = lambda: deque(maxlen=256)

    # -- internals -------------------------------------------------------
    def _space_for(self, z: "torch.Tensor") -> SDMAddressSpace:
        if self.space is None:
            self.space = SDMAddressSpace(z.shape[1], self.sdm,
                                         device=z.device)
        return self.space

    def _write_tag(self, context_id: Optional[Any]) -> int:
        """Which counter column a batch is written to.  The deployment rule is
        the ACTIVE EXPERT -- the only tag the task-ID-free stream provides.
        Diagnostic subclasses may override (e.g. oracle context tags) to
        measure the cost of write-tag noise; any such arm must be reported as
        a diagnostic, never as a competitor."""
        return self.active

    # -- overlap statistics (BOTH sides measured, nothing assumed) ---------
    @staticmethod
    def _welford(st: list, values) -> None:
        for v in values:
            st[0] += 1
            d = v - st[1]
            st[1] += d / st[0]
            st[2] += d * (v - st[1])

    @torch.no_grad()
    def _update_background(self, idx: "torch.Tensor") -> None:
        """After the Transform decision: samples vs the ACTIVE expert's profile
        feed its same-context stats; vs every other expert's profile, its
        cross-context stats.  Both labels hold by construction."""
        space = self.space
        prof = space.profiles()
        if prof is None:
            return
        ov = space.overlaps(idx, prof)                    # (B, K)
        for e in range(prof.shape[0]):
            if space.writes_per_expert[e] == 0:
                continue
            if e == self.active:
                self._same.setdefault(e, self._same_maker()).extend(
                    ov[:, e].tolist())
            else:
                st = self._bg.setdefault(e, [0, 0.0, 0.0])
                self._welford(st, ov[:, e].tolist())

    def _bg_threshold(self, e: int, K: int) -> Optional[float]:
        """SAME-side z-band: a sample hits e iff its overlap is consistent
        with e's measured own-context overlap distribution.  Homogeneous by
        construction (each expert calibrated only on its own context); novelty
        is the default.  None while immature (abstain -> allocate)."""
        ss = self._same.get(e)
        if ss is None or len(ss) < self.sdm.bg_min:
            return None
        from statistics import NormalDist
        z = NormalDist().inv_cdf(1.0 - self.sdm.alpha_false_hit)
        v = np.asarray(ss, dtype=np.float64)
        return float(v.mean()) - z * max(float(v.std(ddof=1)), 1e-6)

    def _pooled_sd(self, e: int) -> float:
        ss = self._same.get(e)
        if ss and len(ss) > 1:
            return 1e-6 + float(np.asarray(ss, dtype=np.float64).std(ddof=1))
        return 1e-6

    # -- Transform: SDM recognition gate ---------------------------------
    def _transform(self, batch_mean: np.ndarray) -> None:
        if not self.sdm.enabled or self.sdm.recognize == "centroid":
            return super()._transform(batch_mean)   # base recognition untouched
        # `_transform` in the base class receives only the batch mean; the SDM
        # gate needs per-sample addresses, stashed by observe() just before.
        idx = self._pending_idx
        space = self.space
        prof = space.profiles() if space is not None else None
        eid = None
        frac = 0.0
        thr_used = float("nan")
        if prof is not None:
            K = prof.shape[0]
            ov = space.overlaps(idx, prof)                # (B, K)
            margin = torch.full_like(ov, -float("inf"))
            for e in range(K):
                if e == self.active:
                    continue                              # base excludes active
                thr = self._bg_threshold(e, K)
                if thr is None:
                    continue                              # abstain -> allocate
                margin[:, e] = (ov[:, e] - thr) / self._pooled_sd(e)
            if bool((margin > -float("inf")).any()):
                best = margin.argmax(dim=1)               # per-sample candidate
                hit = margin.gather(1, best[:, None]).squeeze(1) > 0
                # majority over TOTAL hits; winner is the vote-max among them.
                # Per-candidate majorities let duplicate experts split the vote
                # and force a third duplicate (measured runaway, v0.2 dev).
                frac = float(hit.float().mean())
                if bool(hit.any()):
                    votes = torch.bincount(best[hit], minlength=K)
                    cand = int(votes.argmax())
                    thr_used = self._bg_threshold(cand, K) or float("nan")
                    if frac > self.sdm.vote_majority:
                        eid = cand
        self.recognition_log.append((self.step_count, eid, frac, thr_used))
        if eid is not None:
            self.events.append((self.step_count, "recognize", eid))
            self._activate(eid, trainable=not self.cfg.freeze_on_recognize)
        else:
            new = self._new_expert()
            self.events.append((self.step_count, "allocate", new))
            self._activate(new, trainable=True)

    # -- the public cycle -------------------------------------------------
    def observe(self, x, y, context_id: Optional[Any] = None) -> Decision:
        if not self.sdm.enabled:
            return super().observe(x, y, context_id=context_id)
        if self.device is not None:
            x, y = x.to(self.device), y.to(self.device)
        z = self._phi(x)
        space = self._space_for(z)
        self._pending_idx = space.encode(z)               # for _transform
        d = super().observe(x, y, context_id=context_id)
        # write AFTER the parent's cycle so `self.active` is post-Transform;
        # this is the reinforcement trap -- includes frozen revisits.
        if self.sdm.write_frozen or self.active not in self.library.frozen:
            space.write(self._pending_idx, self._write_tag(context_id))
        # background AFTER the transform decision: the post-transform active is
        # excluded, so every update is cross-context by construction.
        self._update_background(self._pending_idx)
        self._pending_idx = None
        return d

    # -- inference --------------------------------------------------------
    @torch.no_grad() if _HAS_TORCH else (lambda f: f)
    def predict(self, x):
        """Per-sample SDM routing: each sample votes with its activated
        locations.  No batch statistic anywhere on this path."""
        if not self.sdm.enabled:
            return super().predict(x)
        if self.device is not None:
            x = x.to(self.device)
        z = self._phi(x)
        if self.space is None or self.space.counts.shape[1] == 0 \
                or all(w == 0 for w in self.space.writes_per_expert):
            return super().predict(x)                     # nothing written yet
        idx = self.space.encode(z)
        sc = self.space.scores(idx)                       # (B, K)
        K = sc.shape[1]
        if self.sdm.route == "hard":
            assign = sc.argmax(dim=1)
            out = None
            for eid in range(K):
                m = assign == eid
                if not bool(m.any()) or eid not in self.library.experts:
                    continue
                lg = self.library.experts[eid](z[m])
                if out is None:
                    out = torch.zeros(z.size(0), lg.size(1),
                                      device=z.device, dtype=lg.dtype)
                out[m] = lg
            return out if out is not None else super().predict(x)
        # soft: blended read -- logits weighted by the routing posterior
        wts = torch.softmax(sc / self.sdm.soft_temp, dim=1)   # (B, K)
        out = None
        for eid in range(K):
            if eid not in self.library.experts:
                continue
            lg = self.library.experts[eid](z)
            if out is None:
                out = torch.zeros(z.size(0), lg.size(1),
                                  device=z.device, dtype=lg.dtype)
            out += wts[:, eid:eid + 1] * lg
        return out

    @torch.no_grad() if _HAS_TORCH else (lambda f: f)
    def route_ids(self, x):
        """(B,) routed expert id per sample -- the routing-accuracy diagnostic."""
        if self.device is not None:
            x = x.to(self.device)
        z = self._phi(x)
        if self.sdm.enabled and self.space is not None \
                and self.space.counts.shape[1] > 0 \
                and any(w > 0 for w in self.space.writes_per_expert):
            return self.space.scores(self.space.encode(z)).argmax(dim=1)
        ids, C = self.library.centroid_matrix()
        if C is None:
            return torch.zeros(z.shape[0], dtype=torch.long)
        Ct = torch.as_tensor(C, dtype=z.dtype, device=z.device)
        a = torch.cdist(z, Ct).argmin(dim=1)
        return torch.as_tensor([ids[int(j)] for j in a])

    # -- bookkeeping ------------------------------------------------------
    def summary(self) -> dict:
        s = super().summary()
        s.update(sdm_enabled=self.sdm.enabled)
        if self.sdm.enabled and self.space is not None:
            mu0, sig0 = self.space.null_overlap()
            s.update(sdm_dim=self.sdm.dim, sdm_k=self.space.k,
                     sdm_theta=self.space.hit_threshold(len(self.library)),
                     sdm_null_mu=mu0, sdm_null_sigma=sig0,
                     sdm_mbytes=round(self.space.memory_bytes() / 1e6, 1))
        return s


# ------------------------------------------------------------------ self-test
def _selftest() -> int:                                   # pragma: no cover
    """Controls FIRST (this programme found three leaks in its own notebooks):
      1  disabled config is bit-identical to the base machine
      2  per-sample / batch-composition invariance of predict()
      3  eval-mode determinism
    then the mechanism:
      4  overlap statistics: same-context >> theta >> cross-context
      5  union-of-clusters world: SDM routes where centroids collapse
      6  the trap: recurring stream -> recognitions, |M| = true context count
    """
    import torch.nn as nn
    fails = []

    def check(name, cond, detail=""):
        print(f"  {'OK  ' if cond else 'FAIL'} {name}{'  ' + detail if detail else ''}")
        if not cond:
            fails.append(name)

    print("mtf_sdm self-test\n")
    D, K_CLS = 16, 4

    # high-contrast stream: lr=1e-2 settles each context's loss near zero, so
    # H_M fires once per TRUE boundary (the low-lr variant of this stream keeps
    # losses ~1.1-1.7 and its alarms are early-training churn, not boundaries
    # -- discovered while debugging this very test; do not lower lr).
    PER = 40

    def make_machines(sdm_cfg):
        torch.manual_seed(0); np.random.seed(0)
        mk = lambda: nn.Sequential(nn.Linear(D, 32), nn.ReLU(), nn.Linear(32, K_CLS))
        cfg = EDTConfig(n_warm=5, tau_ell=0.3, tau_mu=3.0, lr=1e-2)
        return AddressedUrysohnMachine(mk, cfg, sdm=sdm_cfg)

    def run_stream(mac, n_cyc=3, per=PER, seed=0):
        g = torch.Generator().manual_seed(seed)
        for cyc in range(n_cyc):
            for ctx in range(4):
                base = torch.zeros(D); base[ctx * 4] = 8.0
                for _ in range(per):
                    x = base + torch.randn(32, D, generator=g) * 0.3
                    mac.observe(x, torch.full((32,), ctx), context_id=ctx)
        return mac

    # 1 ---- disabled config is bit-identical ----------------------------
    print("Controls")
    torch.manual_seed(0); np.random.seed(0)
    mk = lambda: nn.Sequential(nn.Linear(D, 32), nn.ReLU(), nn.Linear(32, K_CLS))
    base = UrysohnMachine(mk, EDTConfig(n_warm=5, tau_ell=0.3, tau_mu=3.0, lr=1e-2))
    run_stream(base)
    off = run_stream(make_machines(SDMConfig(enabled=False)))
    xs = torch.cat([torch.zeros(8, D).index_fill_(1, torch.tensor([c * 4]), 8.0)
                    + 0.1 * torch.randn(8, D, generator=torch.Generator().manual_seed(9))
                    for c in range(4)])
    base.eval_mode(); off.eval_mode()
    check("disabled config bit-identical to base machine",
          base.events == off.events and
          torch.equal(base.predict(xs), off.predict(xs)),
          f"{len(base.events)} events each")

    # 2 ---- per-sample / batch-composition invariance --------------------
    on = run_stream(make_machines(SDMConfig(enabled=True, dim=4096,
                                            density=0.03, seed=0)))
    on.eval_mode()
    full = on.predict(xs)
    singles = torch.cat([on.predict(xs[i:i + 1]) for i in range(len(xs))])
    perm = torch.randperm(len(xs), generator=torch.Generator().manual_seed(3))
    permuted = on.predict(xs[perm])
    check("predict(batch)[i] == predict(sample i)",
          torch.allclose(full, singles, atol=1e-5))
    check("batch-composition invariance under permutation",
          torch.allclose(full[perm], permuted, atol=1e-5))

    # 3 ---- determinism --------------------------------------------------
    check("eval-mode determinism", torch.equal(on.predict(xs), on.predict(xs)))

    # 4 ---- overlap statistics -------------------------------------------
    print("\nMechanism")
    sp = on.space
    prof = sp.profiles()
    theta = sp.hit_threshold(prof.shape[0])
    mu0, sig0 = sp.null_overlap()
    # same-context overlap: encode fresh context-0 samples, overlap with the
    # profile of the expert that served context 0
    e0 = next(e for s, k, e in on.events if k == "allocate")
    g = torch.Generator().manual_seed(77)
    z0 = torch.zeros(64, D); z0[:, 0] = 8.0
    z0 += torch.randn(64, D, generator=g) * 0.3
    ov_same = sp.overlaps(sp.encode(z0), prof)[:, e0].mean().item()
    zr = torch.randn(64, D, generator=g) * 3.0            # unrelated inputs
    ov_rand = sp.overlaps(sp.encode(zr), prof).max(dim=1).values.mean().item()
    check("same-context overlap >> theta",
          ov_same > theta, f"{ov_same:.1f} vs theta {theta:.1f} (null mu {mu0:.1f})")
    check("unrelated-input overlap stays near the null",
          ov_rand < ov_same * 0.7, f"{ov_rand:.1f} vs {ov_same:.1f}")

    # 5 ---- union-of-clusters world: centroids collapse, SDM does not ----
    # Context = union of 3 disjoint clusters; context means nearly coincide.
    rs = np.random.RandomState(5)
    n_ctx, n_clu, dim = 4, 3, 32
    mus = rs.normal(0, 4.0, size=(n_ctx, n_clu, dim))
    mus -= mus.mean(axis=1, keepdims=True)   # every context mean is EXACTLY 0:
    # the mixture-mean collapse in its purest form -- centroids carry no signal
    def sample_ctx(c, n, gseed):
        rr = np.random.RandomState(gseed)
        cl = rr.randint(0, n_clu, n)
        return torch.tensor(mus[c, cl] + rr.normal(0, 0.4, (n, dim)),
                            dtype=torch.float32)
    space = SDMAddressSpace(dim, SDMConfig(dim=8192, density=0.03, seed=1))
    cents = []
    for c in range(n_ctx):
        ztr = sample_ctx(c, 300, 100 + c)
        space.write(space.encode(ztr), c)
        cents.append(ztr.mean(0))
    C = torch.stack(cents)
    hits_sdm = hits_cent = tot = 0
    for c in range(n_ctx):
        zte = sample_ctx(c, 200, 200 + c)
        hits_sdm += int((space.scores(space.encode(zte)).argmax(1) == c).sum())
        hits_cent += int((torch.cdist(zte, C).argmin(1) == c).sum())
        tot += 200
    acc_sdm, acc_cent = hits_sdm / tot, hits_cent / tot
    check("SDM routes a union-of-clusters world where centroids collapse",
          acc_sdm > 0.9 and acc_sdm > acc_cent + 0.1,
          f"SDM {acc_sdm:.3f} vs centroid {acc_cent:.3f}")

    # 6 ---- the trap: recurrence -> recognition, |M| -> true count --------
    # every boundary in cycles 2-3 must resolve to a recognition of the RIGHT
    # expert.  Correctness: the recognized expert was first allocated during a
    # presentation of the same context (owner map from the allocate events).
    owner = {e: (s // PER) % 4 for s, k, e in on.events if k == "allocate"}
    recogs = [(s, e) for s, k, e in on.events if k == "recognize"]
    correct = [owner.get(e) == (s // PER) % 4 for s, e in recogs]
    check("recurring stream is recognized, not re-allocated",
          len(recogs) >= 8, f"{len(recogs)} recognitions")
    check("every recognition returns to the right expert",
          all(correct), f"{sum(correct)}/{len(correct)} correct")
    check("|M| tracks the true context count (bounded churn allowed)",
          4 <= on.n_experts <= 6 and len(set(owner.values())) == 4,
          f"{on.n_experts} experts vs 4 true contexts")

    print(f"\n{'PASS -- 6 groups' if not fails else 'FAIL: ' + ', '.join(fails)}")
    return 1 if fails else 0


if __name__ == "__main__":                                # pragma: no cover
    raise SystemExit(_selftest())
